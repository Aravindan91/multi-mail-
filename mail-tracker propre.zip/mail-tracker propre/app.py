import mimetypes
from flask import Flask, request , send_file
# flask c le framework web pr gerer le server 
# request , pr gerer les requette 
# send_file pr envoyer le fichier ( comme le pixel.png ) 
import logging
# logging pr enregistrer les evenemnts 

app = Flask(__name__)         
## on vient de creer une sintance de flash , un gateau du moule                           

#Pour la suite, nous devrons ajouter :
# 1. Une route pour servir le pixel de tracking
# 2. Une fonction pour enregistrer les ouvertures d'emails
# 3. La configuration du logging

# on config le loging pr voir les requette 
# c comme si on cinf un carnet de note des requette 
# logging.basicConfig , on prepare le carnet de note , avec : 
#INFO : les info importante 
# %(asctime)s : date et heure de la requette
#levelsname , le type , le niv d'importance 
# et enfin message , , le contenun du note 
# on aura un truc du genre : 
# 2024-01-20 14:30:45-INFO - Email ouvert par utilisateur@email.com
logging.basicConfig(level=logging.INFO, format = '%(asctime)s-%(levelname)s - %(message)s')

# on creer une route pr servir le pixel de tracking
@app.route("/pixel.png")
def pixel():
    # on recupere l'adresse mail de l'utilisateur
    email = request.args.get("email")
    #on save l'ouverture dans le log 
    if email : 
        logging.inf(f"le pixel tracked pr id : {email}")
    # on enregistre l'ouverture de l email dans un ficher autre 
        try : 
            with open ("save trace email.txt", "a" , encoding="utf-8") as f : 
                time = time.strftime("%Y-%m-%d %H:%M:%S")
                f.write(f" {time} -email ouvert par : {email} \n")
        except Exception as e : 
            logging.error(f"erreur lors du save dans le fihcier , : {e}")
    
    # là on renvoi le pixel de tracking 
    return send_file("pixel.png" , mimetypes='img/png')

## là on va verifier si le server marche bien avc un msg smimple 

@app.route("/")
def msg():
    return "server de tracking online , ok !"

if __name__ == "__main__":
    app.run(debug=False)
    